Full code for the figures
==========================

Code examples for the statistics chapter.

