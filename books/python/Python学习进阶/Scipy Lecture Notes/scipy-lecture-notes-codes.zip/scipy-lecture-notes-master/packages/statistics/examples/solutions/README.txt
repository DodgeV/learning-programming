Solutions to this chapter's exercises
======================================

