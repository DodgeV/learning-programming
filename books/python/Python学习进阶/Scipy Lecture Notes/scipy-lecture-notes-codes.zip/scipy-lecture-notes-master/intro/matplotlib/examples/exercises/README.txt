

Code for the chapter's exercises
--------------------------------

