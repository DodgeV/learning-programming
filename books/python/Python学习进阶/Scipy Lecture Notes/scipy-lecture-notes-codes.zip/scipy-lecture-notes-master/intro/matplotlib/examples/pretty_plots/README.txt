
Code generating the summary figures with a title
-------------------------------------------------

