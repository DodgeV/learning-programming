Full code examples for the numpy chapter
----------------------------------------

