Other Interesting Packages
==========================

* PyAMG
    * algebraic multigrid solvers
    * https://github.com/pyamg/pyamg
* Pysparse
    * own sparse matrix classes
    * matrix and eigenvalue problem solvers
    * http://pysparse.sourceforge.net/
