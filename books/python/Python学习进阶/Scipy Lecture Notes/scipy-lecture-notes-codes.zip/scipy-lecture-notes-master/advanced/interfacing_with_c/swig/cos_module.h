double cos_func(double arg);
