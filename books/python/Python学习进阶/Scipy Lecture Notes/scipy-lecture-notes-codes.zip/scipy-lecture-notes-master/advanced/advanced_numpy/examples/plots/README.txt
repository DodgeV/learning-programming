Examples for the advanced numpy chapter
========================================

