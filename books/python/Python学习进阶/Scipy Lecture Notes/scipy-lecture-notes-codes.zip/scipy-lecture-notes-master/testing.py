"""
A file to ease a bit the testing framework
"""
import doctest
doctest.set_unittest_reportflags(doctest.REPORT_NDIFF)

