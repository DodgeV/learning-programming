
Authors
========

Editors
--------

- Gaël Varoquaux

- Emmanuelle Gouillart

- Olav Vahtras

Chapter authors 
----------------

Listed by alphabetical order.

- Christopher Burns

- Adrian Chauve

- Robert Cimrman

- Christophe Combelles

- André Espaze

- Emmanuelle Gouillart

- Mike Müller

- Fabian Pedregosa

- Didrik Pinte

- Nicolas Rougier

- Gaël Varoquaux

- Pauli Virtanen

- Zbigniew Jędrzejewski-Szmek

- Valentin Haenel (editor from 2011 to 2015)

Additional Contributions
------------------------

Listed by alphabetical order

- arunpersaud

- Lilian Besson

- Matthew Brett

- Lars Buitinck

- Pierre de Buyl

- Ozan Çağlayan

- Adrien Chauve

- Robert Cimrman

- Christophe Combelles

- David Cournapeau

- Török Edwin

- egens

- André Espaze

- Loïc Estève

- Corey Farwell

- Olivier Georg

- Daniel Gerigk

- Robert Gieseke

- Philip Gillißen

- Ralf Gommers

- Emmanuelle Gouillart

- Julia Gustavsen

- Valentin Haenel

- Pierre Haessig

- Michael Hartmann

- Jonathan Helmus

- Tarek Hoteit

- Gert-Ludwig Ingold

- Zbigniew Jędrzejewski-Szmek

- Thouis (Ray) Jones

- jorgeprietoarranz

- kikocorreoso

- Vince Knight

- LFP6

- John McLaughlin

- mhemantha

- Mohammad

- negm

- John B Nelson

- nicoguaro

- Sergio Oller

- Theofilos Papapanagiotou

- patniharshit

- Fabian Pedregosa

- Philippe Pepiot

- Tiago M. D. Pereira

- Nicolas Pettiaux

- Didrik Pinte

- reverland

- Maximilien Riehl

- Nicolas P. Rougier

- Nicolas Rougier

- Rutzmoser

- João Felipe Santos

- Helen Sherwood-Taylor

- Shoeboxam

- Simon

- solarjoe

- ssmiller

- strpeter

- Bartosz T

- Wes Turner

- Akihiro Uchida

- Utkarsh Upadhyay

- Olav Vahtras

- Gael Varoquaux

- Nelle Varoquaux

- Olivier Verdier

- VirgileFritsch

- Pauli Virtanen

- Yosh Wakeham

- Stefan van der Walt

- yasutomo57jp
