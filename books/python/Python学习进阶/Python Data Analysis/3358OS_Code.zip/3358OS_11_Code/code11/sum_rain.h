double sum_rain(int* rain, int len);
