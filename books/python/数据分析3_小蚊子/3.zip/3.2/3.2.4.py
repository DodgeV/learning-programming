# -*- coding: utf-8 -*-
"""
Created on Sun Oct 18 22:25:13 2015

@author: TBKKEN
"""

dic = {}  # 创建空字典
tel = {'Jack':1557, 'Tom':1320, 'Rose':1886}
tel
#{'Tom': 1320, 'Jack': 1557, 'Rose': 1886}

tel['Jack']   # 主要的操作：通过key查询
#1557

del tel['Rose']  # 删除一个键值对
tel

tel['Mary'] = 4127  # 添加一个键值对
tel
#{'Tom': 1320, 'Jack': 1557, 'Mary': 4127}

list(tel.keys())  # 返回所有key组成的list
#['Tom', 'Jack', 'Mary']

sorted(tel.keys()) # 按key排序
#['Jack', 'Mary', 'Tom']

'Tom' in tel       # 成员测试
#True

'Mary' not in tel  # 成员测试
#False

'KEN' in tel

#构造函数 dict() 直接从键值对sequence中构建字典，当然也可以进行推导，如下：
dict([('sape', 4139), ('guido', 4127), ('jack', 4098)])
#{'jack': 4098, 'sape': 4139, 'guido': 4127}

dict(sape=4139, guido=4127, jack=4098)
#{'jack': 4098, 'sape': 4139, 'guido': 4127}

