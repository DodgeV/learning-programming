# -*- coding: utf-8 -*-
"""
Created on Sun Oct 18 22:17:40 2015

@author: TBKKEN
"""

student = {'Tom', 'Jim', 'Mary', 'Tom', 'Jack', 'Rose'}
print(student)   # 重复的元素被自动去掉
#{'Jim', 'Jack', 'Mary', 'Tom', 'Rose'}

'Rose' in student  # membership testing（成员测试）
#True

'KEN' in student  # membership testing（成员测试）

# set可以进行集合运算
a = set('abracadabra')
b = set('alacazam')
a
b
#{'a', 'b', 'c', 'd', 'r'}
a - b     # a和b的差集
#{'b', 'd', 'r'}
a | b     # a和b的并集
#{'l', 'm', 'a', 'b', 'c', 'd', 'z', 'r'}
a & b     # a和b的交集
#{'a', 'c'}
a ^ b     # a和b中不同时存在的元素
#{'l', 'm', 'b', 'd', 'z', 'r'}

a = ['him', 25, 100, 'her', 100, 25]

#判断多个值，那么就要用到set
set([25, 100]) <= set(a)