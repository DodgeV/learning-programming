import numpy;
from pandas import read_csv;

df = read_csv("D://PA//4.9//data.csv");

r = numpy.random.randint(0, 10, 3);

df.loc[r, :];
