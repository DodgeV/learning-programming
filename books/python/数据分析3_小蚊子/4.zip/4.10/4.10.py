import pandas;
from pandas import read_csv;

df1 = read_csv("D://PA//4.10//data1.csv", sep="|");
df2 = read_csv("D://PA//4.10//data2.csv", sep="|");
df3 = read_csv("D://PA//4.10//data3.csv", sep="|");

df = pandas.concat([df1, df2, df3])
