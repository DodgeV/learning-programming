from pandas import read_csv;

df = read_csv('D://PA//4.3//data.csv')

newDF = df.drop_duplicates();

