#http://www.tbk.ren/article/19.html

from pandas import read_csv;

df = read_csv('D://PA//4.1//1.csv')
df

df = read_csv('D://PA//4.1//1.csv', encoding='UTF-8')
 
