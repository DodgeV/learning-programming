# coding UTF-8

from pandas import read_table;
from pandas import DataFrame;

df = read_table('D://Python//2.3//中文.txt', sep=',', encoding='UTF-8')
df
