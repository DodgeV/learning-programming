from pandas import read_excel;

df = read_excel('D://PA//4.1//3.xlsx', sheetname='data')
