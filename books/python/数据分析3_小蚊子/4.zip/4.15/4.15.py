import pandas;
from pandas import read_csv;

df = read_csv("D:\\PA\\4.15\\data.csv", sep='|');

bins = [min(df.cost)-1, 20, 40, 60, 80, 100, max(df.cost)+1];

labels = ['20以下', '20到40', '40到60', '60到80', '80到100', '100以上'];

pandas.cut(df.cost, bins)

pandas.cut(df.cost, bins, right=False)

pandas.cut(df.cost, bins, right=False, labels=labels)
