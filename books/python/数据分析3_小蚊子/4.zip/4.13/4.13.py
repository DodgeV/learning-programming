from pandas import read_csv;

df = read_csv("D:\\Python\\3.4\\1.csv", sep="|");

result = df.price*df.num
