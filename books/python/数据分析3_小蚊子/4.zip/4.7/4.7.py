from pandas import Series;
from pandas import DataFrame;
from pandas import read_csv;

df = read_csv("D:\\Python\\3.2\\2.csv");

newDF = df['name'].str.split(' ', 1, True);

newDF.columns = ['band', 'name'];

