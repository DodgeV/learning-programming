from pandas import read_csv;
from pandas import to_datetime;
from datetime import datetime;

df = read_csv("D:\\PA\\4.17\\data.csv", encoding='utf8')

df_dt = to_datetime(df.注册时间, format='%Y/%m/%d');

df_dt_str = df_dt.apply(lambda x: datetime.strftime(x, '%d-%m-%Y'));
