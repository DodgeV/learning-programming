import pandas;
from pandas import read_csv;

df = read_csv("D://PA//4.8//data.csv", sep="|");

df[df.comments>10000];

df[df.comments.between(1000, 10000)]

df[pandas.isnull(df.title)]

df[df.title.str.contains('台电', na=False)]

df[(df.comments>=1000) & (df.comments<=10000)]
