from pandas import read_csv;
from pandas import to_datetime;

df = read_csv('D:\\PA\\4.18\\data.csv', encoding='utf8')

df_dt = to_datetime(df.注册时间, format='%Y/%m/%d');

df_dt.dt.year

df_dt.dt.second;
df_dt.dt.minute;
df_dt.dt.hour;
df_dt.dt.day;
df_dt.dt.month;
df_dt.dt.weekday;
