import pandas;
from pandas import read_csv;

items = read_csv(
    "D://PA//4.12//data1.csv", 
    sep='|', 
    names=['id', 'comments', 'title']
);
prices = read_csv(
    "D://PA//4.12//data2.csv", 
    sep='|', 
    names=['id', 'oldPrice', 'nowPrice']
);

itemPrices = pandas.merge(
    items, 
    prices, 
    left_on='id', 
    right_on='id'
);
