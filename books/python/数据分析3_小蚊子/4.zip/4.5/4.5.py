from pandas import read_csv;

df = read_csv('D://PA//4.5//data.csv')

newName = df['name'].str.strip();

df['name'] = newName;
