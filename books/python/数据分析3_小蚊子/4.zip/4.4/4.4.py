from pandas import read_csv;

df = read_csv('D://PA//4.4//data.csv');

newDF = df.dropna();

