from pandas import read_csv;

df = read_csv("D:\\PA\\4.14\\data.csv");

scale = (df.score-df.score.min())/(df.score.max()-df.score.min())
