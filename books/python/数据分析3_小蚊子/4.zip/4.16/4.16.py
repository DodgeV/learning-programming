from pandas import read_csv;
from pandas import to_datetime;

df = read_csv("D:\\PA\\4.16\\data.csv", encoding='utf8')

df_dt = to_datetime(df.注册时间, format='%Y/%m/%d');
