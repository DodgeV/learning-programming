import numpy;
from pandas import read_csv;

data = read_csv('D:\\PA\\8.2\\data.csv');
data['score2'] = data['score']*2

data.groupby(by=['class'])['score'].agg({
    '总分':numpy.sum, 
    '人数':numpy.size, 
    '平均值':numpy.mean, 
    '方差':numpy.var, 
    '标准差':numpy.std
})

data.groupby(by=['class', 'name'])[['score', 'score2']].agg([
    numpy.size, 
    numpy.sum
])

result = data.groupby(by=['class'])['score'].agg({
    '总分':numpy.sum, 
    '人数':numpy.size, 
    '平均值':numpy.mean, 
    '方差':numpy.var, 
    '标准差':numpy.std
})

result.index
result.columns
result['平均值']

result2 = data.groupby(by=['class', 'name'])[['score', 'score2']].agg([
    numpy.size, 
    numpy.sum
])

result2.index
result2.columns
result2['score']
result2['score']['sum']

result.reset_index()
result2.reset_index()