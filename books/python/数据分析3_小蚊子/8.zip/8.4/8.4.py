﻿import numpy;
import pandas;
from pandas import read_csv;

df = read_csv('D:\\PA\\8.4\\data.csv');

bins = [min(df.年龄)-1, 20, 30, 40, max(df.年龄)+1];
labels = ['20岁以及以下', '21岁到30岁', '31岁到40岁', '41岁以上'];

年龄分层 = pandas.cut(df.年龄, bins, labels=labels)
df['年龄分层'] = 年龄分层;

r1 = df.pivot_table(
    values=['年龄'], 
    index=['年龄分层'], 
    columns=['性别'], 
    aggfunc=[numpy.size, numpy.mean]
);

r2 = df.pivot_table(
    values=['年龄'], 
    index=['年龄分层'], 
    columns=['性别'], 
    aggfunc=[numpy.std]
);

r1.join(r2)

