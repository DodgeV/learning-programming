from pandas import read_csv;

data = read_csv('D:\\PA\\8.1\\data.csv')

data.score.describe()

data.score.size

data.score.max();

data.score.min;

data.score.sum;

data.score.mean;

data.score.var;

data.score.std;
