import numpy;
from pandas import read_csv;

data = read_csv('D:\\PA\\8.5\\data.csv');

data_pt = data.pivot_table(
    values=['月消费（元）'], 
    index=['省份'], 
    columns=['通信品牌'], 
    aggfunc=[numpy.sum]
);

data_pt.sum()

data_pt.sum(axis=0)

data_pt.sum(axis=1)

data_pt.div(data_pt.sum(axis=1), axis=0);

data_pt.div(data_pt.sum(axis=0), axis=1);
