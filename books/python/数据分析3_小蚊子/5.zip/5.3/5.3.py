# -*- coding: utf-8 -*-
import numpy;
import matplotlib;
from pandas import read_csv;
import matplotlib.pyplot as plt;

data = read_csv('D:\\PA\\5.3\\data.csv');

gb = data.groupby(
    by=['通信品牌'], 
    as_index=False
)['号码'].agg({
    '用户数':numpy.size
});

#pip install matplotlib

font = {
    'family' : 'SimHei'
}

matplotlib.rc('font', **font);

plt.pie(gb['用户数'], labels=gb['通信品牌'], autopct='%.2f%%');

plt.show()
