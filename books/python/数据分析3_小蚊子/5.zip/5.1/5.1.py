import matplotlib;
from pandas import read_csv;
import matplotlib.pyplot as plt;

data = read_csv("D:\\PA\\5.1\\data.csv")

font = {
    'family' : 'SimHei'
}
matplotlib.rc('font', **font);

plt.plot(data['广告费用'], data['购买用户数'], '.')

#plt.plot(data['广告费用'], data['购买用户数'], 'o')

#plt.plot(data['广告费用'], data['购买用户数'], 'o', color='yellow')
#plt.plot(data['广告费用'], data['购买用户数'], 'o', color=(1, 1, 0))
#plt.plot(data['广告费用'], data['购买用户数'], 'o', color='#FFFF00')
plt.xlabel('广告费用');

plt.ylabel('购买用户数');
plt.grid(True);

plt.show();
