# -*- coding: utf-8 -*-
import urllib.request;

#pip install BeautifulSoup4
from bs4 import BeautifulSoup;

response = urllib.request.urlopen('file:///D:/Python/6.1/html.html');

html = response.read();
html

soup = BeautifulSoup(html);
soup

soup.find('tr');
soup.find_all('tr');
