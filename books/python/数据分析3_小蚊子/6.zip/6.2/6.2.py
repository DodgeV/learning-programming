# -*- coding: utf-8 -*-
import json;
import urllib.request;

response = urllib.request.urlopen('file:///D:/PA//6.2//json.json');
jsonString = response.read();

jsonObject = json.loads(jsonString.decode())

jsonObject['employees']
jsonObject['employees'][0]
jsonObject['employees'][0]['lastName']