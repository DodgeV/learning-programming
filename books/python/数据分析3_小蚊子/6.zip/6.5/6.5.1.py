# -*- coding: utf-8 -*-
import json;
import urllib.request;

from pandas import Series;
from pandas import DataFrame;

from bs4 import BeautifulSoup;

response = urllib.request.urlopen('http://item.jd.com/1185291.html');

html = response.read();

soup = BeautifulSoup(html);

divSoup = soup.find(id="product-detail-2")

data = DataFrame(columns=['Feature', 'Property'])

trs = divSoup.find_all('tr');

for tr in trs :
    tds = tr.find_all('td');
    if len(tds)==2:
        f=tds[0].getText();
        p=tds[1].getText();  
        data = data.append(
            Series(
                [f, p], 
                index=['Feature', 'Property']
            ), ignore_index=True
        );

len(data)   

response = urllib.request.urlopen('http://p.3.cn/prices/get?skuid=J_1185291');
jsonString = response.read();

jsonObject = json.loads(jsonString.decode())

jsonObject[0]['p']
