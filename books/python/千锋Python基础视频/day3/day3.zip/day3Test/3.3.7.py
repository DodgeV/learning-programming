import  time

timesdata=time.time()
print(timesdata)
timesdata=int(timesdata)
print(timesdata)
timesdata=timesdata%10   #数字限定在0-26之间
print("%",timesdata)

print(chr(ord('0')+timesdata))#基数+变数形成随机字符
print(ord('Z'))