import os
os.system("gedit")