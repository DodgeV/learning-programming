
#print(round(10.029999))
#print(round(10.029999,2))#四舍五入到2位

print(10.03*100)
print(int(round(10.03*100))%10)



money=input("input  money")
print(money)
print(int(eval(money)),"元")
print(int(eval(money)*10)%10,"角")
print(int((eval(money))*100)%10,"分")

#10.03    10.029999999