cmd = None
cmd=2
if cmd:
    print("有对象")
else:
    print("没有对象")