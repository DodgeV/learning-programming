申凌瑞的身高=176
申凌瑞的颜值=99
申凌瑞的RMB=100000

春哥要求的身高=180
春哥要求的颜值=97
春哥要求的RMB=10000000

ismarry1=  (申凌瑞的身高>=春哥要求的身高)
ismarry2=  (申凌瑞的颜值>=春哥要求的颜值)
ismarry3=  (申凌瑞的RMB>=春哥要求的RMB)


print(ismarry1,ismarry2,ismarry3)
if  ismarry1 or ismarry2 or  ismarry3:
    print("春哥就要嫁给申凌瑞")
else:
    print("你真是好人，可惜我们不合适")

#or有一个满足即可，全部不满足才会淘汰