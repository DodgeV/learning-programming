
王涛="天才"
if  王涛=="天才":  #判断成立,执行或者不成立，不执行
    print("天生的唇彩")#python中间的空格起到代码块分隔作用
print("hello world")