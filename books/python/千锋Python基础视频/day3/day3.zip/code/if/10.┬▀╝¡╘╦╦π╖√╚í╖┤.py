

李佳奇的性别=True
#1+2-3
if  not  not  李佳奇的性别:
    print("boy")
else:
    print("girl")

    #  not  True=  false
    #not  false= True
    #not结合性  从右往左