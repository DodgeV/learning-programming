mystr=input("妹子的潜台词")
if  mystr=="我不想破坏我们之间的友谊":
    print("我们之间仅仅会有友谊")
elif mystr=="你真是一个好人":
    print("还没好到我想要的成都")
elif mystr=="给我一段时间考虑":
    print("不给我时间我怎么开溜")
elif  mystr=="我有对象了":
    print("这个人是专门为你虚构的")
elif mystr=="我还有没有勇气接受你":
    print("看到你差点没被吓死，还敢接受你")
elif mystr=="我们还是做朋友好了":
    print("你还有利用价值，有义务，没权利")
elif mystr=="我妈妈不让我谈恋爱":
    print("是我不想跟你谈恋爱")
elif mystr=="我还小":
    print("你做我备胎，等我找不到再说")
else :
    print("没有回答是一种回答，没有收录")

#给岁月以妹子，而不要给妹子以岁月，给时光易生命，而不是给生命以时光
