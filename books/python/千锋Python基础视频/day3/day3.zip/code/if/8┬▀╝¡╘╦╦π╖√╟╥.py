#申凌瑞
申凌瑞的身高=186
申凌瑞的颜值=99
申凌瑞的RMB=100000e4

凤姐要求的身高=180
凤姐要求的颜值=97
凤姐要求的RMB=10000000

ismarry1=  (申凌瑞的身高>=凤姐要求的身高)
ismarry2=  (申凌瑞的颜值>=凤姐要求的颜值)
ismarry3=  (申凌瑞的RMB>=凤姐要求的RMB)
print(ismarry1,ismarry2,ismarry3)
if  ismarry1 and  ismarry2 and  ismarry3:
    print("凤姐就要嫁给申凌瑞")
else:
    print("有多远滚多远")

#and,少一个都不行，
