'''
申凌瑞，食人国国王
1.说真话，砍头      我被绞死

2.说假话，绞死      我被绞死

if  (真话)
砍头

if  (假话)
绞死


if  (真话)
砍头

else  :
绞死

'''

if  0:
    print("hello python")
else:
    print("hello html5")
