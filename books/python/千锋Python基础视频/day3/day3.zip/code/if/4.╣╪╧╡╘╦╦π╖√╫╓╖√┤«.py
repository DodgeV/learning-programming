bt1="ab备胎"
bt2="ac备胎"
bt3="aa备胎"
print(bt1!=bt2) #判断字符串不等
print(bt1==bt2) #判断字符串相等

print(bt1 <bt2)  #字符串的关系运算符 ，比较大小，用于排序
print(bt2 >bt1)  #按照ASCII排序,字符的编号排序，第一个相等对比第二个，第二个相等对比第三个

print(ord("0"))
print(ord('a'))
print(ord('b'))
print(ord('z'))
