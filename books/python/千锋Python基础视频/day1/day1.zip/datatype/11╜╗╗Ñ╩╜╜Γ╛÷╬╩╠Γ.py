
R=input("请输入圆形的半径")
print(R)
print(type(R))
R=eval(R) #字符串转化为数值
print(type(R))
print(R*R*3.1415926535)