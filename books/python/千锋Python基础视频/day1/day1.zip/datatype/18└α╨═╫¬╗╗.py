'''
num=3
print(type(num))
num=str(num)  #str(要转换为字符串的数据)
print(type(num))
'''
#eval.字符串转数字

num=4.5
print(int(num)) #int(取整数)

