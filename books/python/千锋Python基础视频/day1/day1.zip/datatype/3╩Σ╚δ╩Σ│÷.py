#mystr=input("请输入数据")#input输入，mystr接收输入的值
#print(mystr)#print输出

import  os
mystr=input("输入指令")
os.system(mystr)