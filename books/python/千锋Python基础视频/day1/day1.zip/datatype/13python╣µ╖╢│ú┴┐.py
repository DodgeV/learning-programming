PI=3.1415926535 #PI只是规范起来，用于表示常量，实际是变量，
print(PI)
PI=123
print(PI)
