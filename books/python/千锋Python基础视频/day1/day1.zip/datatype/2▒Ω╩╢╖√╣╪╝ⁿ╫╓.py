#num1=2  #num是一个变量，Num1就是标识符区别于其他变量
#Num1=3
#print(num1,Num1)

'''
#语法可以，规范不行
a="12321"
b=12
c=12312.45
'''
import keyword  #编译器自带关键字，不允许用于命名变量函数类，
print(keyword.kwlist)

as1=14


