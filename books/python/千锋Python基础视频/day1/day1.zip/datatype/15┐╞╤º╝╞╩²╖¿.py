data=1.5e3   #1.5*10^3
print(data)
data=1.5e-4 #1.5 /10/10/10/10
print(data)

data=100.8**10000000#超过数字范围
print(data)
