num=10.56
print(round(num)) #四舍五入