num=10
#num=num+1
num +=  1 #等价num=num+1,+=连在一起
print(num)#11
num-=3
print(num)#8
num*=3
print(num)#24
#num/=2#整数整数结果实数，两个有一个是实数，结果总是实数
print(num)
num//=2#整数整数结果整数,两个有一个是实数，结果是实数
print(num)
num %=5  #num=num%5
print(num)
num**=3  #num=num**3
print(num)
