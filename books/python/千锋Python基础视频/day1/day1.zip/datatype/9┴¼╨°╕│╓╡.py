#num1=2
#num2=3
num1=num2=10 #连续赋值
print(num1,num2)