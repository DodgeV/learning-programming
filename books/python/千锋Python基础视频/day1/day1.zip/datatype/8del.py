num=1
print(num)
num=2
print(num)
del num #删除变量，不能再用
print(num)
