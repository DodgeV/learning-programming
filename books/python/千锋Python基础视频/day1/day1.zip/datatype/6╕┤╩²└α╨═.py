data=1+2j
print(data)
print(type(data))#复数数据类型