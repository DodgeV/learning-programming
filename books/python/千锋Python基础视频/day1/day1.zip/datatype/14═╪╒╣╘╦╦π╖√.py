num1=100
num2=15
print(num1+num2)
print(num1-num2)
print(num1*num2)
print(num1/num2)#/求实数
print(num1//num2)#//整除
print(num1%num2)#求余数  100=6*15+10
print(num1**3) #**开方，  num1*num1*num1
#num1**0.5,求平方根
