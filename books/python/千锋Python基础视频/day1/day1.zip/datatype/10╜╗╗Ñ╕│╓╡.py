num1,num2,num3=1,2,3  #num=1,num2=2
print(num1,num2,num3)#必须对称，交互对称赋值