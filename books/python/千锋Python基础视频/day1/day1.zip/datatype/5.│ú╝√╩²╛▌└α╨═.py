num=10
print("王涛女神备胎的数量=",num)
print(type(num))

money=1234.58
print("王涛为了泡凤姐花了",money)
print(type(money))

王涛isgay=False
print(type(王涛isgay))


王涛的女神的name ="凤姐"
print(王涛的女神的name)
print(type(王涛的女神的name))