'''
王涛女神备胎的数量=13
print(王涛女神备胎的数量)
print(type(王涛女神备胎的数量))#type(var),求var的类型
print(id(王涛女神备胎的数量))#内存地址，id(var)

'''
#python变量可以改变数据类型
'''
num1=10
print(num1)
print(type(num1))
num1=20
print(num1)
print(type(num1))
num1="calc" #字符串
print(num1)
print(type(num1))

'''

num1=3
num2=3
print(num1,num2)#print打印多个数据，逗号分隔
print(id(num1),id(num2))
num1=10
print(id(num1),id(num2))

