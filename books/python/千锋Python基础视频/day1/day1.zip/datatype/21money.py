#10.84
#11.83
#10.84*10=108.4 -108=0.4/10=0.04
data=eval(input("输入RMB"))
print(   (    data*10  -  (int(data*10))   )      /10   )