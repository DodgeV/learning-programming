#ch='的'
#print(ord(ch))
print(chr(25105))
print(chr(30340))

