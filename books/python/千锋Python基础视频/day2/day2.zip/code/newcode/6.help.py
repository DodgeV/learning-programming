import math
print(dir(math))#显示所有函数方法
print(help(math.atan))#显示函数说明