#print("a",end=" ") #end默认是\n换行，end=""空，end=" "空格
#print("a",end=" ")
#print("a",end=" ")
print(1,2,3)
print(1,2,3,sep="----")  #print连续打印，默认是空格间隔，也可以其他方法间隔
