import os
#os.system('calc')  #'="
#os.system("calc")  字符串三种，',","""换行
os.system("""calc""")