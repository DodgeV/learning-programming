#import os
#os.system("\"C:\Program Files (x86)\Tencent\QQLite\Bin\QQScLauncher.exe\"")

print("he\nllo\"\'")