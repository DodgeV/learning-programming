#ch1='A'
#ch2='AB'
#print(type(ch1),type(ch2)) #python,只有字符串类型

ch1='a'
print(ord(ch1)) #ord求字符的编号，字符串长度只能为1
print(chr(97)) #chr求编号为97的字符