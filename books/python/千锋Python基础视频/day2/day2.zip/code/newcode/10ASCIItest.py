ch='B'
print(chr(ord(ch)+32))
#print(chr(ord(ch)+2))
#加密
#hello
#ifmmp