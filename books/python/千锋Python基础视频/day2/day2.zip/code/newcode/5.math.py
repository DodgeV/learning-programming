import math  #导入数学包
print(abs(-5))
print(abs(5))#求绝对值
print(max(1,20,10,202,40))#返回最大值
print(min(1,20,10,202,40))#返回最大值
print(pow(2,4))#2^4=2*2*2*2
print(math.sqrt(9)) #平方根
print(math.sin(3.1415926535))#sin