#类，人类->动物类->生物
#对象，郭俊就是人类实例化的对象

print(type("abc"))
print("abc".upper())#"abc“是一个str类型的对象
print("abc".find("b")) 