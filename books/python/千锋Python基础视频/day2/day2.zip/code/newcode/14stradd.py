import os
mystr1="note"
mystr2="pad"
mystr3="C:\\Users\\Tsinghua-yincheng\\Desktop\\"+str(1)+".txt"
os.system(mystr1+mystr2+" "+mystr3) #字符串加法