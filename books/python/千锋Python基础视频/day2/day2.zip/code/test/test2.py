str1="calc"
str2="calc"  #地址赋值
print(id(str1),id(str2))
str1="calc1"  #给变量赋值，实际上传递新的常量的地址
print(id(str1),id(str2))