num  #变量没有赋值，不可以引用
print(num)