'''
a=5
print(a+1)  #a+1不会改变原来的值
a=a+1  #要改变原来的值，需要赋值
print(a)
'''
doubledb=1024.88
print(int(doubledb))
print(doubledb)

