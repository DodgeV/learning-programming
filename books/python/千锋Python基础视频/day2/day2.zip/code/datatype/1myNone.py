num=10
num=None  #None,主要用于判断变量有没有人正在使用。
print(num)
print(type(None))