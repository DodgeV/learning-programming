function varargout = gui15(varargin)
% GUI15 M-file for gui15.fig
%      GUI15, by itself, creates a new GUI15 or raises the existing
%      singleton*.
%
%      H = GUI15 returns the handle to a new GUI15 or the handle to
%      the existing singleton*.
%
%      GUI15('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GUI15.M with the given input arguments.
%
%      GUI15('Property','Value',...) creates a new GUI15 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before gui15_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to gui15_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help gui15

% Last Modified by GUIDE v2.5 29-May-2010 09:17:23

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @gui15_OpeningFcn, ...
                   'gui_OutputFcn',  @gui15_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before gui15 is made visible.
function gui15_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to gui15 (see VARARGIN)

% Choose default command line output for gui15
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes gui15 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = gui15_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --------------------------------------------------------------------
function Untitled_1_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function jm1_Callback(hObject, eventdata, handles)
% hObject    handle to jm1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
h2 = [handles.axes2 handles.ims];
set(h2, 'Visible', 'off');
h1 = [handles.axes1 handles.sin handles.cle];
set(h1, 'Visible', 'on');
try
    delete(allchild(handles.axes2));
end

% --------------------------------------------------------------------
function jm2_Callback(hObject, eventdata, handles)
% hObject    handle to jm2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
h2 = [handles.axes2 handles.ims];
set(h2, 'Visible', 'on');
h1 = [handles.axes1 handles.sin handles.cle];
set(h1, 'Visible', 'off');

% --- Executes on button press in cle.
function cle_Callback(hObject, eventdata, handles)
% hObject    handle to cle (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in sin.
function sin_Callback(hObject, eventdata, handles)
% hObject    handle to sin (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
ezplot(handles.axes1, 'sin(x)');

% --- Executes on button press in ims.
function ims_Callback(hObject, eventdata, handles)
% hObject    handle to ims (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
axis(handles.axes2);
imshow('pout.tif');
