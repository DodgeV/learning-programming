% �������ʾ��
hf = figure('Units', 'Normalized', ...
    'Position', [0.2 0.3 0.5 0.5], ...
    'Menu', 'none');

ha = axes('Parent', hf, 'Units', 'Normalized', ...
    'Position', [0.1 0.1 0.8 0.8]);

hl = line('Parent', ha, 'XData', [0:0.01:7], ...
    'YData', sin([0:0.01:7]), 'Color', 'r', ...
    'LineWidth', 3);

cstring = 'gbkmy';

for k = 1:5
    pause(3);
    set(hl, 'Color', cstring(k));
end