function varargout = gui18(varargin)
% GUI18 M-file for gui18.fig
%      GUI18, by itself, creates a new GUI18 or raises the existing
%      singleton*.
%
%      H = GUI18 returns the handle to a new GUI18 or the handle to
%      the existing singleton*.
%
%      GUI18('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GUI18.M with the given input arguments.
%
%      GUI18('Property','Value',...) creates a new GUI18 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before gui18_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to gui18_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help gui18

% Last Modified by GUIDE v2.5 03-Jun-2010 22:35:37

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @gui18_OpeningFcn, ...
                   'gui_OutputFcn',  @gui18_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before gui18 is made visible.
function gui18_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to gui18 (see VARARGIN)

% Choose default command line output for gui18
handles.output = hObject;

global ButtonDown pos1
ButtonDown = [];
pos1 = [];

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes gui18 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = gui18_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on mouse press over figure background, over a disabled or
% --- inactive control, or over an axes background.
function figure1_WindowButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global ButtonDown pos1;
if strcmp(get(gcf, 'SelectionType'), 'normal')
    ButtonDown = 1;
    pos1 = get(handles.axes1, 'CurrentPoint');
end


% --- Executes on mouse motion over figure - except title and menu.
function figure1_WindowButtonMotionFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global ButtonDown pos1

if ButtonDown == 1
    pos = get(handles.axes1, 'CurrentPoint');
    line([pos1(1, 1) pos(1, 1)], [pos1(1, 2) pos(1, 2)], 'LineWidth', 4);
    pos1 = pos;
end


% --- Executes on mouse press over figure background, over a disabled or
% --- inactive control, or over an axes background.
function figure1_WindowButtonUpFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global ButtonDown
ButtonDown = 0;