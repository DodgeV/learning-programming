w=linspace(0.1,5,1000)*pi;
sys1=zpk([1],[0 1 1.7],5);
nyquist(sys1,w)
figure
nyquist(sys1,w)
title('K=10ʱ��nyquistͼ')
