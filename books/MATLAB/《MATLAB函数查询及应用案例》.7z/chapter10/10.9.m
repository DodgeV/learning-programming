A=[6,1.5,7.5];
B=[4,2,8];
tu = tf(A,B);
bode(tu)
