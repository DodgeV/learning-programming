A=[1,-0.3,0.02];
B=[1,0.7];
sys=tf(B,A);
figure;
subplot(211);
impulse(sys,20);
subplot(212)
step(sys,20)
