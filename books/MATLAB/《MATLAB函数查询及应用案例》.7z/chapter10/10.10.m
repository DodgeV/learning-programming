sys1=zpk([1],[0 1 1.7],5);
[kg1,r1,wg1,wc1]=margin(sys1)
margin(sys1)
