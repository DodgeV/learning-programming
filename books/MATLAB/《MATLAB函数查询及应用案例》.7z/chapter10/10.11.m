G=tf(1,conv(conv([1,1],[3,1]),[7,1])); %�������ݺ���
kp=[0.1,2.0,2.4,3.0,3.5]; 
for i=1:5
G=feedback(kp(i)*G,1);
step(G);hold on
end
gtext('kp=0.1'); gtext('kp=2.0'); gtext('kp=2.4'); gtext('kp=3.0'); gtext('kp=3.5');
