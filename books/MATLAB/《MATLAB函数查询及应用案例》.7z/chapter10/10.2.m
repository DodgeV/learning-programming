sys=tf([7,-5],[1,-3,8]); 
subplot(1,2,1),step(sys)
subplot(1,2,2),step(sys,20)
