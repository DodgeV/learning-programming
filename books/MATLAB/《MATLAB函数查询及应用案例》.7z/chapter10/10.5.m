a=[0,1;-10,-5];
b=[1;3];
c=[1,2];
d=[0];
x0=[1 0];
figure
initial(a,b,c,d,x0)

