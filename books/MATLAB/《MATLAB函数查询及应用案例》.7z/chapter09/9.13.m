 proj=newsro('srotut1','Kint') 
 simget(proj)
  simset(proj,'Solver','ode23')
  simget(proj)