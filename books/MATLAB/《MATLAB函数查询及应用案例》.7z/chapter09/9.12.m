proj=newsro('srotut1','Kint')
 simget(proj)