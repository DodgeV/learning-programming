 open_system('vdp');
 blks = find_system(gcs, 'Type', 'block');
 listblks = get_param(blks, 'BlockType')

