load_system('vdp');
vdp;
close_system('vdp');				%�ر�ϵͳ
