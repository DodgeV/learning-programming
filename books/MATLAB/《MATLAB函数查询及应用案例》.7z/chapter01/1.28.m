M = magic(3);
dlmwrite('myfile.txt', [M*5 M/5], ' ')
dlmwrite('myfile.txt', rand(3), '-append', ...
   'roffset', 1, 'delimiter', ' ')