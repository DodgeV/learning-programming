y=0;
n=200;
for i=1:1:n
y=y+i;
end
disp(y)
