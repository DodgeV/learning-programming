y=1;
n=0;
while (n<20)
n=n+1;
y=y*n;
end
disp(y)
