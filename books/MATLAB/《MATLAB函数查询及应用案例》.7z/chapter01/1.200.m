clc
fid = fopen('D:\temps.dat', 'r');
degrees = char(176);
degrees = fscanf(fid, ['%d' degrees 'F']);