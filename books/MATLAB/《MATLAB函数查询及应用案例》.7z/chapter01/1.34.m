m=[12 19 27 0];
for j=1:length(m)
   if (m(j)~=0) 
     continue;
   else 
       k=j;
end
end
