whos
clear str
whos