fid = fopen('mydata.m','r');
s = '';
while ~feof(fid) 
   line = fgetl(fid);
   if isempty(line) || ~ischar(line), break, end
   s = sprintf('%s%s\n', s, line);
end
disp(s);
fclose(fid);