rmpath('D:\ProgramFiles\MATLAB7\Mywork')
path
