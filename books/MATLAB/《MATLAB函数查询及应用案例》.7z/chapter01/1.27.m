A = ['abc 46 6 ghi'; 'def 7 89 jkl'];
for k = 1:2
   C(k,:) = sscanf(A(k, :)', '%*s %d %d %*s', [1, inf]);
end
