functioln d=det(B) 
if isempty(B)
    d=1;
    return
else 
else
