keyboard
for i=1:9
       for j=1:5
             x(i,j)=2*i+3*j;
       end
    end
x
