productclass=input(' productclass =');
switch productclass
     case 1
         disp('It are good!')
     case 2
         disp('It can pass!')
     case 3
         disp('It can��t pass!')
 otherwise
     disp('data error!')
end
