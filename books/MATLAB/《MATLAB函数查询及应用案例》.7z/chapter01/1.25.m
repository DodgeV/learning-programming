fid = fopen('alphabet.txt', 'r');
fseek(fid, 5, 'bof');
A = fread(fid, 10, 'uint8=>char');
fclose(fid);
A;