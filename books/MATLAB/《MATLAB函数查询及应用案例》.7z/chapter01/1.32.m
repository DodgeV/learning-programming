x=input('enter x��');
if x<2
        y=14*x+3;
        disp(y);
elseif x>=2 && x<10
        y=x-13;
        disp(y);
else
        y=x*x+2*x-2;
        disp(y);
end
