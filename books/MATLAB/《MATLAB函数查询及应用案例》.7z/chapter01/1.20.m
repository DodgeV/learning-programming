fid = fopen('d:\mydata.dat', 'r');
a = fscanf(fid, '%g %g', [2 inf]);    % It has two rows now.
a = a';
fclose(fid)