a = magic(4)
save -ascii mydata.dat
clear
load mydata.dat
mydata
