fid = fopen('alphabet.txt', 'r');
c = fread(fid, '*char')
fclose(fid);