addpath('D:\ProgramFiles\MATLAB7\Mywork',0) 
path   
