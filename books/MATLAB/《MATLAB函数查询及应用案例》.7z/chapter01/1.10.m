>> x=[1 2 3;2 3 4];
>> [m,n]=size(x)
>> M=size(x,1)
>> M=size(x,2)
m =
     2
n =
     3
M =
     2
M =
     3
