>> what D:\ProgramFiles\MATLAB7\toolbox\robot\@link 

