 Str = [pi 65 66 67];
 sprintf('%s %f %s', Str)
 