load vonkoch
figure(1) 
plot(vonkoch)
figure(2)
COEFS=cwt(vonkoch,1:5,'haar','plot'); 
