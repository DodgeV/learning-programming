A=magic(2);
B=2*ones(2);
A>=B
ge(A,B)
