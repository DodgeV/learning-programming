A=[5,7,9,3;11,19,12,5;3,18,12,24]
sort(A)
 sort(A,2)
sort(A,'descend')
[B,IX]=sort(A,'descend')
