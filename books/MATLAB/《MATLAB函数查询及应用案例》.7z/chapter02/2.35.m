A=magic(2);
B=2*ones(2);
A<=B
le(A,B)
