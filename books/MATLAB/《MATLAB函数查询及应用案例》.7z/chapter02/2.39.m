A=ones(2)
 B=[1,0;0,1]
A&B
 and(A,B)
