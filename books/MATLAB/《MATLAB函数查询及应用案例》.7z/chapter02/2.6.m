x=1;
atan(x)
