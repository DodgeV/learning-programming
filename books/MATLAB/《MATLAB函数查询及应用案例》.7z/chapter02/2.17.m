 z=3+2i;
real(z)
