A=magic(2);
 isreal(A)
