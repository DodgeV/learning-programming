A=[1,4,6;8,3,11;2,9,7];
B=sum(A,1,'double')
class(B)
C=sum(A,2,'native')
class(C)
