 a=6;
 tanh(a)
