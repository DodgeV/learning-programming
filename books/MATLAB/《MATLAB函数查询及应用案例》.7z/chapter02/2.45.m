 A=[1,0,1;0,0,2;1,1,1];
 B=ones(3);
 isequal(A,B)
