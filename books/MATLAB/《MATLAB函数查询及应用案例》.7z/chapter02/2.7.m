 x=1+2i;y=2+3i;
a=1;b=2;
 atan2(x,y)
