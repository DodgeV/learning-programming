a=-3;
b=3+4i;
abs(a)
abs(b)
