A=magic(2);
B=2*ones(2);
A==B
eq(A,B)
