z=3+4i
abs(z)
atan2(4,3)
z=r*exp(i*theta)