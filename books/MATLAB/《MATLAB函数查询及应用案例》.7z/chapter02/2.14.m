a=6;
 atanh(a)
