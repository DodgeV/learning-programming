 z=3+4i;
zc=conj(z)
