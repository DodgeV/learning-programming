asin(0.5)
 asin(2)
