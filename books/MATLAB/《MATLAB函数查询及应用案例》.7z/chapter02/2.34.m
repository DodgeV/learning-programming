A=magic(2)
B=ones(2)
A>B
gt(A,B)
