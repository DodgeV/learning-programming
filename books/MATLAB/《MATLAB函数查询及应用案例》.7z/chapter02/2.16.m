z=2+1*i;
angle(z)
