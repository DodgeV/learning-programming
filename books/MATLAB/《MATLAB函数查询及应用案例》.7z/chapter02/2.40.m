 A|B
 or(A,B)
