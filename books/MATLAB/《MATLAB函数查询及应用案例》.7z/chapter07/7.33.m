syms x y 
ezplot('x^2-2*y^4')








