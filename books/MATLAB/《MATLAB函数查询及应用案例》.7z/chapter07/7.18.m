syms x y
y = collect((x+y)*(x^2+y^2+1), y)  
