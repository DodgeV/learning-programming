syms x
expand((x+2)^5)
expand((x-2)*(x-4))


