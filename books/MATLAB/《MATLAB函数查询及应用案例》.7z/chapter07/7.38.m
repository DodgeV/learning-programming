%fh = @(x,y) x.*exp(-x.^2-y.^2);
fh =@(x,y) sqrt(x^2+y^2)+3*(1-x).^2;
ezmesh(fh,40)


