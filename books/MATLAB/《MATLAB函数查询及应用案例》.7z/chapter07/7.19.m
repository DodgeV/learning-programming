 syms x 
 horner(x^4+13*x^3-9*x^2+19*x-4)

