S=solve('x+y=10','x-2*y=20'); 
S.x
S.y
