A = sym('[a , 2*b ; 3*a , 0]')


