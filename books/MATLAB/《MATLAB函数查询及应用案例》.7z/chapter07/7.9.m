syms x y z t u;
f = 1/(1 + x^2); g = sin(y); h = x^t; p = exp(-y/u);
compose(f,g)    
compose(f,g,t)  
compose(h,g,x,z)
compose(h,g,t,z)
compose(h,p,x,y,z)
compose(h,p,t,u,z)