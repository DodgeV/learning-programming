syms x y 
fh = @(x,y) sqrt(x^2+y^2)+3*(1-x).^2;
ezcontourf(fh,[-3,3],49)


