 syms t
 ezpolar(t*sin(t)*cos(t)) 

