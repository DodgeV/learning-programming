syms a b c
A=[1 a+c 3;a 6 c^2;2 b+c a];
A1=det(A)
A2=simple(A1)
