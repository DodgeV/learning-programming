A = sym(pascal(2)) 
B = eig(A)
pretty(B)