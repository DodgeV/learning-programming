factor(x^2+2*x-3)


