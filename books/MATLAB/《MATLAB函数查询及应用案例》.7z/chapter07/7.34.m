syms t
ezplot3('cos(t)','2*sin(t)','t',[0,6*pi]) 









