poly2sym([12 8 7 5],x)
