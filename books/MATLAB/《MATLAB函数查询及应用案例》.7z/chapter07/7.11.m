syms k n x
symsum(k^2)
symsum(k^2,0,20)