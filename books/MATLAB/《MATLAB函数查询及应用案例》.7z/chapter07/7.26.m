B=[4/17, sqrt(2); 9.2, log(3)]
C=sym(B)




