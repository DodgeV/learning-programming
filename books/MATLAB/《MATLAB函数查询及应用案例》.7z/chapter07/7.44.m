S = dsolve('Dx = y', 'Dy = -x') 
S.x
S.y