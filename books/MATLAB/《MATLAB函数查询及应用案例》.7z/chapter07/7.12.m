a=11; b=19;  
y='a*x+b';   
subs(y)      
subs(y,'x','w')
