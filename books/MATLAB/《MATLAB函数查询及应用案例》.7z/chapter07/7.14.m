syms a x
f = 1/(a^2 + x^2);
F = int(f, x, -inf, inf)  
