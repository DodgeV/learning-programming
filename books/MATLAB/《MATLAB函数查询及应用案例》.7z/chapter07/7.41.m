syms x y 
ezsurfc('(x^2+y)/(1+2*x^2+6*y^2)','circ')



