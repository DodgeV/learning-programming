A=[12 2;4 9]; 
d=eig(sym(A))    








