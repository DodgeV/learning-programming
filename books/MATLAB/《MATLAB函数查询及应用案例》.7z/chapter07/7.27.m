 A=[14 5 6;7 28 19];  
 sym(A)
 B=transpose(A)




