t=0:.5:20
x=sawtooth(t,0.5)
stem(t,x)
