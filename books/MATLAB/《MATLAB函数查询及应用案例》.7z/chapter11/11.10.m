t=0:0.5:2
y=sinc(t)
b=randn(1,3) 
conv(y,b)
