 Z = [ 1 - 1i 2 + 1i 3 - 1i 4 + 1i 
1 + 2i 2 - 2i 3 + 2i 4 - 2i 
1 - 3i 2 + 3i 3 - 3i 4 + 3i  ] 
 P = angle(Z)
