signal=zeros(1,6)
signal(2)=1