t = 0:0.001:10;         
y = chirp(t,0,1,250);     
subplot(2,1,1);plot(t,y);
subplot(2,1,2);
spectrogram(y,256,250,256,1E3,'yaxis') 
