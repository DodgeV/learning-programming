signal= randn(10,1) ;                      
acsignal=xcorr(signal,5,'biased')
acsignal((5+1):2*(5+1)-1)
