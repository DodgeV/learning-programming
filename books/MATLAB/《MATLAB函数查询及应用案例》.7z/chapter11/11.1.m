t=[-3:0.0001:3];
y=tripuls(t,4,0.5);
plot(t,y);grid on
axis([-3,3,-1.5,1.5])
