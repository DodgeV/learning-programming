b = fir1(80,0.2);         
freqz(b,1,2048,75000,'whole')
