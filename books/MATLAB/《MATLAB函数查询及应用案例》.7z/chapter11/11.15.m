sig=[1 3 5 7 9]
x=hilbert(sig,6)
