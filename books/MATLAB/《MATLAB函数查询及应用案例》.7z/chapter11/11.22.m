a=[3,2,3,2];
b=[1,4,1,3];
[h,j]=freqs(b,a);
grpdelay(h,j,128) 
