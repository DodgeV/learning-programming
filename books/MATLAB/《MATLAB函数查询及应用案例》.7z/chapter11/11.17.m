abs(-6)
abs(12+9i)
abs('xinhao')
