x=rand(1,5) 
y=rand(1,5)
c=xcorr(x,y)  
