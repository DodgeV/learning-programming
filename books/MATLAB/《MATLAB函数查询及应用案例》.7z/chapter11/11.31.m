[b,a] = cheby2(7,0.7,300/500,'high'); 
freqz(b,a,256,1000)
