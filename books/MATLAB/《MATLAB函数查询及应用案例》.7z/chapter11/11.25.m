data = [1:0.2:4];
a=[3,2,3]
b=[1,4,1]
y=filter(b,a,data)
