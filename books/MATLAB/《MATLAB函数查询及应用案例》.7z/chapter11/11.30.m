[b,a] = cheby1(5,1.0,200/500,'high'); 
freqz(b,a,256,1000)
