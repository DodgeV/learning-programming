t=0:0.005:1; 
x=sinc(t);             
sig=x+rand(1 ,length(t)); 
subplot(1,2,1);
plot(sig(1:60));                                 
title('ԭʼ�ź�ͼ'); 
ftt_sig=fft(sig,512);    
p=ftt_sig.*conj(ftt_sig)/512;                    
f=1000*(0:255)/512;                           
subplot(1,2,2);
plot(f,ftt_sig(1:256))        
title('�������ܶȷֲ�ͼ');