t=0:0.5:2
y=sinc(t)
x=mean(y)
