num = [16]; 
den = [18 4 3 -3]; 
[r,p,k] = residuez(num,den)
