[b,a] = ellip(6,5,60,300/500,'s') 
[bz,az] = impinvar(b,a,10)
