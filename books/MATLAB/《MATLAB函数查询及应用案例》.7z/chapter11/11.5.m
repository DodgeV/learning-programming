t=-4:.2:4;                                     
signal=sinc(t);                       
plot(t,signal)   
