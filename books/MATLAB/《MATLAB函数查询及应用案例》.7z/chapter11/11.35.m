 b = fir1(25,0.6,'stop');   
freqz(b,1,512)
