t=0:0.5:2
y=sinc(t)
x=std(y)
