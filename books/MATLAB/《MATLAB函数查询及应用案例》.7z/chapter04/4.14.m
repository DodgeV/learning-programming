 x=-1:0.1:1;
 y=sin(x);
gradient(y)
