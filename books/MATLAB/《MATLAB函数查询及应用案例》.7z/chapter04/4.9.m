c=[5 3 0 -7];
 x=[11 3 17];
 polyval(c,x)
