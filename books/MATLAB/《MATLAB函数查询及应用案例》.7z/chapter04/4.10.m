b=[5 3 -1 9];
 a=[4 -3 2];
 [r,p,k]=residue(b,a)
