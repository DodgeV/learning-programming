 x=0:3:21;
 y=[18 19 19.5 23 27 26.5 24 20];
 xi=[1.5:3:19.5];
 yi=interp1(x,y,xi,'spline');
 plot(x,y,':og',xi,yi,'*b')
