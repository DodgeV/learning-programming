 x=0:pi/100:pi;
  y=sin(x)+x.^2+1;
 z=trapz(x,y)
