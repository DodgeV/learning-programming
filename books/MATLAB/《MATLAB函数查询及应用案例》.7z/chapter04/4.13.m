 fun=@(x,y,z)(x.^2+y.^3).*sin(z);
 q=triplequad(fun,0,3,2,5,0,pi)
