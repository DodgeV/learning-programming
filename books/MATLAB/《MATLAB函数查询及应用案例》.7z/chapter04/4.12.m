 fun=@(x,y)x.^2+y.^2+x.*y;
 z=dblquad(fun,0,3,2,5)
