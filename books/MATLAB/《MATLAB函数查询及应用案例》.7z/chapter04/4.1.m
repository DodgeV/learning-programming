fun=@(x)x^3+2*x^2+4*x-3;
[x,fval,editflag,output]=fminbnd(fun,2,5)
