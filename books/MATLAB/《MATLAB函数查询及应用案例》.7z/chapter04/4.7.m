c=[3 2 0 -1 5];
r=roots(c)
