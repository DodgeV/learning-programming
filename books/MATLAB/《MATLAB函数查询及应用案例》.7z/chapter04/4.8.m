 a=[3 0 6 -3];
 b=[2 -3 5];
 k=polyder(a,b)
