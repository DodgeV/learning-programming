A=magic(3);
 poly(A) 