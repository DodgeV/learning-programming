A=[1 2 ;3 4];B=[ 5 6;7 8];
 C=times(A,B)