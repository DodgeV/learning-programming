A=magic(4);
 triu(A)
