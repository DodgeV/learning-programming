 A=[1 2 3;4 5 6];B=magic(3);
 C=mtimes(A,B)