A=[1 2 -1 3;2 1 -5 -1;1 1 -3 1];B=[2 3 5]';
 C=[A,B];
rankA=rank(A)
rankC=rank(C)
X1=null(A,'r')
X2=pinv(A)*B
syms k
 X=k.*X1+X2
