a1=ones(2)
 a2=magic(2)
 A=blkdiag(a1,a2)