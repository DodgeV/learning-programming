 a=1:4 
 A=diag(a,-1)
  b=diag(A,-1)