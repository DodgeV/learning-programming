A=[1 -1 0 0;1 1 0 3;3 -1 8 0;1 3 -9 7];
B=[1 1 0 0 ]';
C=[A,B];
rank(A)
 rank(C)
X=A\B 
rref(C)
 X=inv(A)*B 
