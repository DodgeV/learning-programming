A=[1 2 3];
B=[4 5 6]
 cross(A,B)
