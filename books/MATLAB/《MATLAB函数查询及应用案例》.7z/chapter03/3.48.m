A=magic(3);B=ones(3);
union(A,B,'rows') 
