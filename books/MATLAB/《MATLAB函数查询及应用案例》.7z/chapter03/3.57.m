 A=eye(3);
 n=nnz(A)
