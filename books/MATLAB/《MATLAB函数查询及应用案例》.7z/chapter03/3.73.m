 S=sparse([1 3 5],[1 2 4],[7 8 9])
 A=full(S)