 A=[1 2;3 4];B=3;
 C=mpower(A,B)