A=magic(3)
sum(A)
sum(A,2)
