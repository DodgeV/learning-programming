A=eye(3);
n=nzmax(A)
