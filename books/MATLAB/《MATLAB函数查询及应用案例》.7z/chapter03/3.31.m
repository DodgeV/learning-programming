A=magic(3);B=[1 2 3]';
C=mldivide(A,B)    
