 A=[1 2;3 4];B=3;
  C=power(A,B)