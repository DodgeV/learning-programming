A=magic(3);
 B=spdiags(A)
