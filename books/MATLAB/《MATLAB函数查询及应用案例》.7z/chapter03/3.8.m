A(:,:,1)=magic(3)A(:,:,2)=ones(3)
numel(A)