A=magic(3);
 [X,alpha,condest]=sqrtm(A)