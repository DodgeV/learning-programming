 A=[1 2 3 4 1 5 2]
 [b,i,j]=unique(A,'first')
