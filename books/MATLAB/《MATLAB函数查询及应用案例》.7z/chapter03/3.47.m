x=1:3;
y=3:6;
 conv(x,y,'same')
conv(x,y)
