A=[4 5 6;1 2 3];B=[7 8 9];
C=mrdivide(A,B)
