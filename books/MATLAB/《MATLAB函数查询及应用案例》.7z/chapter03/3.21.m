 r=[2 5 8 9];
 c=1:4;
 T=toeplitz(c,r)