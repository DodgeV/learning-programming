A=magic(3);
B=ones(3);
dot(A,B)
