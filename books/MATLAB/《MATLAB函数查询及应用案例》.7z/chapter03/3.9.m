B=rand(3,6,11);
length(B)