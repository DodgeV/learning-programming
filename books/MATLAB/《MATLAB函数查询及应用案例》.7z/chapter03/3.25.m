A=magic(3);
B=eye(3); 
C=plus(A,B)