A=pascal(4)
 R=chol(A)