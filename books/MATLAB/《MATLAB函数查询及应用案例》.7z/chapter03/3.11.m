A=magic(4)
B=reshape(A,2,8) 
reshape(A,2,[])