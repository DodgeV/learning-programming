A=[1 2 2 1;2 1 -2 -2 ;2 -2 -8 -6];B=[2 3 5]';
C=[A,B];
 rankA=rank(A)
 rankC=rank(C)
X=pinv(A)*B
 norm(A*X-B)
