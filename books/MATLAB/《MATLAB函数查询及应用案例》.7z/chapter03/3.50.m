A=magic(3);
c=cond(A) 
