A1=ones(2)
A2=magic(2)
 A=cat(2,A1,A2)
  B=cat(1,A1,A2)