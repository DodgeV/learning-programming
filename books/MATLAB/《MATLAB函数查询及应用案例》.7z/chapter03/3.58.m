A=[1 0 2;3 6 0;4 2 3];
C=nonzeros(A)
