A=magic(3)
n=trace(A)