A=magic(4);
 tril(A)
