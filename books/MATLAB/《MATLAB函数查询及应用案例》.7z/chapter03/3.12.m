 A=zeros(3)
 B=zeros(2,'double')