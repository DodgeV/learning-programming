A=magic(4);
pinv(A)