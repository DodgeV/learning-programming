size(rand(2,3,4))
 [m,n]=size(rand(2,3,4))