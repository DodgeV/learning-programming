A=magic(2);B=[5  6;7  8];
C=rdivide(A,B)
