 A=[1 2 ;3 4];B=ones(2);
 C=ldivide(A,B)  
