syms x,y ;
 factor(x^3-y^3)
