 A=magic(3);
 n1=norm(A)
  n2=norm(A,1)
   n3=norm(A,2) 
    n4=norm(A,'fro')
     n5=norm(A,'inf')