 A=[2 3 4;0 4 5;0 -7 4];
[V,D]=eig(A)
[V,D]=cdf2rdf(V,D)
