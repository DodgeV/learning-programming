x=0:pi/180:2*pi;
y1=exp(-0.3*x).*sin(x);
semilogy(x,y1)
