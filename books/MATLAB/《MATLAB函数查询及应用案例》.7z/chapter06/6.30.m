BW=imread('D:\test\jianzhu.jpg')
imwrite(BW,'D:\test\jianzhu.tif','tif')
imshow(BW)
