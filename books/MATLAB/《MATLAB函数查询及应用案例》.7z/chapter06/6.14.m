x=0:0.1:6;
y=sin(x);
area(x,y)
