x=0:0.001:3.44;
g=0.7*sin(0.25*pi*x)+0.3*sin(pi*x);
figure1=plot(x,g)
print(gcf,'-depsc2','D:\matlab\mytest.eps')
