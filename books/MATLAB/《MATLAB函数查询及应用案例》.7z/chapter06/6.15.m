x = [1 3.5 0.5 2.5 2];
explode = [0 1 1 0 0];
pie3(x,explode);
colormap hsv
