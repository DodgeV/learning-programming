S=imread('D:\test\hua.png')
A=rgb2gray(S)
imshow(A)
