fh = @(x,y) x.*exp(-x.^2-y.^2); 
ezmesh(fh,40) ;
