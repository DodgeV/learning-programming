x=0:0.05:5;
y=cos(x); 
plot(x,y); 
