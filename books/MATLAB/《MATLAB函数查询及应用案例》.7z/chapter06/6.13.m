[X,Y,Z] = peaks(40); 
surfc(X,Y,Z) 
axis([-3 3 -3 3 -10 5])
