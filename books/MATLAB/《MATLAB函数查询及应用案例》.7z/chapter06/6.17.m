x = linspace(-2*pi,2*pi,40); 
stairs(x,cos(x)) 
