x=0:0.001:3.44;
g=0.7*sin(0.25*pi*x)+0.3*sin(pi*x);
plot(x,g);
hold on
x=linspace(0,3.44,10);
g=0.7*sin(0.25*pi*x)+0.3*sin(pi*x);
plot(x,g)
