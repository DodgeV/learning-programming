x=0:0.2:8;
y1=0.2+cos(-2*x);                
y2=sin(x.^0.5);                  
figure(1);                       
plot(x,y1);                        
figure(2);                     
plot(x,y2)                       
