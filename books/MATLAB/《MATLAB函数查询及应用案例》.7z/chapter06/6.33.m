originalRGB = imread('D:\test\meigui.png'); 
subplot(121)
imshow(originalRGB) 
h = fspecial('motion', 50, 45);%����һ���˲��� 
filteredRGB = imfilter(originalRGB, h); 
subplot(122)
imshow(filteredRGB) 
