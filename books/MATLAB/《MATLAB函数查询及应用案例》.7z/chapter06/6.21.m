x= linspace(0,2*pi,30);
y = 5*cos(x);
L=0.2*y;
U=0.3*y;
errorbar(x,y,L,U);
