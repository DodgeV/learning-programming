I=imread('D:\test\huahuidu.png')
subplot(2,2,1),imshow(I,[24,160])
subplot(2,2,2),imshow(I,[161,256])
