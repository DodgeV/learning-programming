RGB1 = imread('D:\test\hai.jpg'); 
RGB2 = imadjust(RGB1,[.2 .3 0; .6 .7 1],[]); 
subplot(121);imshow(RGB1)
subplot(122);imshow(RGB2)
