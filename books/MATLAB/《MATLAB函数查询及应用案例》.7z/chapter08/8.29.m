h=figure;
get(h);
