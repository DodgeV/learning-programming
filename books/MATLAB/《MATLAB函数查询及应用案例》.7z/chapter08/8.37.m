h=figure;
uicontrol(h,'callback','close(gcbf)');
