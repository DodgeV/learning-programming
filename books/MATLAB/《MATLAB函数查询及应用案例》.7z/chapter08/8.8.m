 h=figure;
 axis;
 printpreview(h);
