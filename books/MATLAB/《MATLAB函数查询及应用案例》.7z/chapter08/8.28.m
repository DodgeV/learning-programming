h=figure;
set(h,'color','blue');
