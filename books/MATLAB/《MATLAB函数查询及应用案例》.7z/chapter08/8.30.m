h=figure;
set(gcf,'color','blue');
