h=figure;
h_pb=uicontrol(h,'Style','listbox','position',[20,20,200,400])
set(h_pb,'ButtonDownFcn','selectmoveresize')
