h=figure;
uicontrol(h,'style','checkbox','string','Check')
