h=figure;
guidata(h,[20,20]);
guidata(h)
