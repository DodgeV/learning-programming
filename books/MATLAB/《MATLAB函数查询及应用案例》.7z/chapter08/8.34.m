>> h=figure;
f=waitforbuttonpress;
if f
    set(h,'color','red');
end
