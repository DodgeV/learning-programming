h=figure();
setappdata(h,'name','123');
getappdata(h,'name')
