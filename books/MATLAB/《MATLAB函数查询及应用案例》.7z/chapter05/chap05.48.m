x=poissrnd(2,1,100);
[lambdahat,lambdaci]=poissfit(x)
