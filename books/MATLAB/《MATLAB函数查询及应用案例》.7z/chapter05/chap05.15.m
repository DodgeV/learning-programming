random('beta',2,3,1,10)
random('wbl',2,0.5,1,10)