x=wblrnd(2,3,1,100);
[parmhat,parmci]=wblfit(x)
