load reaction;
nlintool(reactants,rate,@hougen,beta,0.01,xn,yn)
