x=normrnd(0,1,1,100);
[muphat,sigmaphat,mupci,sigmapci]=normfit(x)
