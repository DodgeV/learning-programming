x=unifrnd(8,10,1,100);
[ahat,bhat,ACI,BCI]=unifit(x)
