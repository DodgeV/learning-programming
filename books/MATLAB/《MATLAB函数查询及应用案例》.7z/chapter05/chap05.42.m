x=betarnd(2,4,100);
x=betarnd(2,4,1,100);
[phat,pci]=betafit(x)
