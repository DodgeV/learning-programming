x=exprnd(5,1,100);
[muhat,muci]=expfit(x)
