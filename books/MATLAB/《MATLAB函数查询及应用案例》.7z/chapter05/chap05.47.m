x=normrnd(0,1,1,100);
[nlogl,avar]=normlike([0 1],x)
