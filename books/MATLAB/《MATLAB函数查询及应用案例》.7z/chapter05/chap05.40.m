p=[2 3 2];
polyval(p,[5 7])
