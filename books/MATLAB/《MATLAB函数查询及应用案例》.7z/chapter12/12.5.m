P = [1 2 3];
T = [2.0 4.1 5.9];
net = newlind(P,T);
Y = sim(net,P)
