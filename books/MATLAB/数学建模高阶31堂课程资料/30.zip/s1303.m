clc,clear
a=load('data1602.txt')
x=a([1,4],:);x=x';x=x(:);
y=a([2,5],:);y=y';y=y(:);
dx=diff(x);
dy=diff(y);
temp=x(1:end-1).*y(1:end-1);
a=[-temp -x(1:end-1) zeros(19,2);zeros(19,2) -temp -y(1:end-1)];
b=[dx;dy];
nihe=a\b