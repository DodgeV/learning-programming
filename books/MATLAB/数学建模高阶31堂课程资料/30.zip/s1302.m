clc,clear
a=load('data1301.txt')
t0=a([1:2:end],:);t0=t0';t0=t0(:);
h0=a([2:2:end],:);h0=h0';h0=h0(:);
D=18.6;
V=pi/4*D^2*h0;
dv=gradient(V,t0)
no1=find(h0==-1)
no2=[no1(1)-1;no1(2)+1;no1(3)-1;no1(4)+1];
t=t0;t(no2)=[];
dv2=-dv;dv2(no2)=[];
plot(t,dv2,'*')
pp=csape(t,dv2);
tt=0:0.1:t(end);
fdv=ppval(pp,tt);
hold on,plot(tt,fdv)
T=trapz(tt(1:241),fdv(1:241))

