clc,clear
a=imread('pc2.png')
imwrite(a,'pc2.jpg')
subplot(1,2,1),imshow(a)
subplot(1,2,2),imshow(pc2.jpg)
