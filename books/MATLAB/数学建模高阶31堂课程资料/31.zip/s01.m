clc,clear
ab0=load('data1102.txt');
mu=mean(ab0);sig=std(ab0);
ab=zscore(ab0);
a=ab(:,[1:7]);b=ab(:,[8:12]);
[XL,YL,XS,YS,BETA,PCTVAR,MSE,stats]=plsregress(a,b);
xw=a\XS;
yw=b\YS;
ncomp=input('����ɷֶԵĸ���=');
[XL2,YL2,XS2,YS2,BETA2,PCRVAR2,MSE2,stats2]=plsregress(a,b,ncomp);
n=size(a,2);m=size(b,2);
beta3(1,:)=mu(n+1:end)-mu(1:n)./sig(1:n)*BETA2([2:end],:).*sig(n+1:end);
beta3([2:n+1],:)=(1./sig(1:n))'*sig(n+1:end).*BETA2([2:end],:);
bar(BETA2','k')
yhat=repmat(beta3(1,:),[size(a,1),1])+ab0(:,[1:n])*beta3([2:end],:);
ymax=max([yhat;ab0(:,[n+1:end])]);
figure
for i=1:5
    subplot(2,3,i)
    plot(yhat(:,i),ab0(:,n+i),'*',[0:ymax(i)],[0:ymax(i)],'Color','k')
    legend('y',2)
    hold on
end
