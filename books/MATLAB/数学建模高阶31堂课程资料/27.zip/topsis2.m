clc,clear
a=load('data1201.txt');
a=a';
[m,n]=size(a);
for j=[1 5 7 9]
    b(:,j)=(max(a(:,j))-a(:,j))/(max(a(:,j))-min(a(:,j)));
end
for j=[2 3 4 6 8]
    b(:,j)=(a(:,j)-min(a(:,j)))/(max(a(:,j))-min(a(:,j)));
end
cs=max(b);c0=min(b);
for i=1:m
    ds(i)=norm(b(i,:)-cs);
    d0(i)=norm(b(i,:)-c0);
end
f=d0./(ds+d0);
[sf,ind]=sort(f,'descend');
xlswrite('1201.xls',[ds;d0;f])
